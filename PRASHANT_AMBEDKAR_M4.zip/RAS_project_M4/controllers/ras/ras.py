# Task 4 : TO merge all previous activities and combine to work together. Also an concept of Subsumption architecture is introduced.

# Subsumption architecture is a behavior-based robotics control system that creates complex behavior by combining reactive components. It organizes control systems in hierarchical structures, leveraging hybrid methods like behavior trees and reinforcement learning algorithms, which are encapsulated within classes.
# Each behavioral component of the robot is traced and stored in separate files, and they are arranged based on their execution priority order. This approach allows for efficient management and organization of the robot's behaviors, enabling it to respond effectively to its environment and achieve its tasks.

# 1) the priority order is the car must drive in road.
# 2) the car must explore all area.
# 3) whenever the battery drains out the car must move to charging area(identified in priority #2)
# 4) the should halt after observing `STOP` symbol

# We are relied on random turns to explore the entire region and find the charging area, but this approach was based on luck and chance. Sometimes, the car's battery would drain out completely before the charging area was discovered. 

import numpy as np

from rasrobot import RASRobot

from CarMovements import *
from SimulationMap import simulationMap
from StopDetection import *

import cv2

from collections import deque


class MyRobot(RASRobot):
    def __init__(self):
        """
        The constructor has no parameters.
        """
        super(MyRobot, self).__init__()

        self.queue = deque(maxlen=15)

        self.vehicle_state = None

        self.start_point = None

        # Minimap for mapping path and Navigation
        self.simulationMap = simulationMap(size=50, map_scale_factor=40)
        self.stop_timer = None
        self.previous_charge = 440

        self.stop_templates = get_stop_templates()
        self.last_stop_time = None

    def is_charging(self):# The is_charging function evaluates battery or energy storage system activity by comparing current charge level to a predefined threshold, indicating charging or charging.
        # previous_charge represents battery charge level, self.time_to_live represents threshold value for efficient system operation.
        return self.previous_charge <= self.time_to_live

    def is_low_charge(self):# The is_low_charge function checks if a battery's remaining charge level is low by comparing it to a 160-point threshold value.
        return self.time_to_live <= 160

    def is_charged(self):
        return self.time_to_live >= 1 * 240

    def get_road(self):# Function get_road in autonomous driving or robotics processes camera image for road information extraction.

        image = self.get_camera_image()

        # Pre-process the image
        processed_mask = pre_process_image(image)# Pre_process_image function extracts road and relevant information from image, storing it in processed_mask.

        # Lane Region of Interest Mask
        roi_mask = GetRegionMaskValue(image, roi_type='lane')

        processed_mask = cv2.bitwise_and(processed_mask, roi_mask)# Processed_mask and lane ROI mask refined using bitwise AND operation.

        # Apply the mask to the image
        image_view = apply_mask(image, roi_mask)# Apply_mask function highlights lane region in image by filling contour with roi_mask.

        image, stop_sign = scan_for_template(image, self.stop_templates)

        return image, cv2.morphologyEx(image_view, cv2.MORPH_OPEN, (3, 3)), processed_mask, stop_sign

    def run(self):
        """
        This function implements the main loop of the robot.
        """
        prev_turn_rate = 0
        prev_charging_state = False

        while self.tick():

            # Setting initial offset to the origin
            if self.start_point is None:# Initialize vehicle's GPS position and set origin offset for simulation map.
                self.start_point = self.get_gps_values()
                self.simulationMap.set_origin_offset(self.start_point)

            speed = 40

            raw_image, image, road_mask, stop_sign = self.get_road()# the get_road method to get the raw camera image, processed image with road mask, and information about the presence of a stop sign.

            # Check if the stop sign detection is active (not on cooldown)
            if is_stop_detection_active(self.last_stop_time):
                if stop_sign is True:
                    self.stop_timer = time.time()
                    self.last_stop_time = time.time()
                    

            if self.stop_timer is not None and time.time() - self.stop_timer < 10:                
                speed = 0
            else:
                speed = 40
                self.stop_timer = None

            turn_rate, v_state = TurningValueofPath(image, road_mask, prev_turn_rate, self.vehicle_state, self.is_low_charge(), self.simulationMap)# Calculates turn rate and vehicle state using image and road mask, considering low charge state and zebra crossing presence.
            self.vehicle_state = v_state

            if self.is_low_charge() and not self.is_charging() and int(self.time_to_live) % 20 == 0:
                print(f'Charge Draining: {self.time_to_live}')

            # Clear path once reached to charging points
            if self.is_charging():
                self.simulationMap.path.clear()

            if abs(turn_rate) >= 20:
                speed = carturnspeed

            # Wait until 100% charged
            if self.is_charging() and not self.is_charged():
                speed = 40

            self.set_speed(speed)
            self.set_steering_angle(turn_rate / 100)

            prev_turn_rate = turn_rate

            # Update the simulationMap based on gps
            self.simulationMap.update(self.get_gps_values(), self.vehicle_state, self.is_charging())

            # Set charging point once identified (start point)
            if self.is_charging() and len(self.simulationMap.charging_points) == 0:
                    self.simulationMap.set_charging_point()

            # Set charging point once identified (end point)
            if not self.is_charging():
                if prev_charging_state and len(self.simulationMap.charging_points) == 1:
                    self.simulationMap.set_charging_point()


            self.previous_charge = self.time_to_live
            prev_charging_state = self.is_charging()
            print(f'Time to live: {self.time_to_live}')

            print(f'GPS: {self.get_gps_values()}')

            cv2.imshow('Simulation Map',self.simulationMap.get_map())

            print('We relied on random turns to explore the entire region and find the charging area, but this approach was based on luck and chance. Sometimes, the cars battery would drain out completely before the charging area was discovered. ')         

            print('If Battery Drains out completely without exploring charging and other areas, then Please Re-Run the code!!')

            print('-----------------------------------------------------------------------------------------------------------------')
            # cv2.imshow('Simulation Map', self.simulationMap.get_map())
            self.simulationMap.show()
            cv2.waitKey(1)


# The API of the MyRobot class, is extremely simple, not much to explain.
# We just create an instance and let it do its job.
robot = MyRobot()
robot.run()
