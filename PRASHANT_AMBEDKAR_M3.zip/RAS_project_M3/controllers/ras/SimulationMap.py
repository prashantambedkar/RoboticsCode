#Reference of Path finding using Dijkstra Algorith:
    # 1) https://medium.com/@alfarizmfauzan/autonomous-robotics-algorithm-path-planning-djikstra-with-python-7da8c0f80aee
    # 2) https://gist.github.com/betandr/541a1f6466b6855471de5ca30b74cb31
    # 3) https://github.com/AtsushiSakai/PythonRobotics/tree/master
    # 4) https://www.udacity.com/blog/2021/10/implementing-dijkstras-algorithm-in-python.html
# the following below code is referred from above links

import cv2
import numpy as np
from pathfinding.core.diagonal_movement import DiagonalMovement
from pathfinding.core.grid import Grid
from pathfinding.finder.dijkstra import DijkstraFinder
from InitVariables import *
import pickle

# Map built based on gps values of the vehicle
class simulationMap:
    def __init__(self, size, map_scale_factor=15, base_color=(0,0,0)):
        self.size = size
        self.map_scale_factor = map_scale_factor
        self.origin_offset = (0, 0)
        self.current_position = (0, 0)
        self.previous_position = (0, 0)

        self.map = np.full((size, size, 3), base_color, dtype=np.uint8)
        self.charging_points = []
        self.path = []

        self.previous_position_set = set()
        # with open('map_data.pkl', 'rb') as file:
            # self.map = pickle.load(file)

    def set_origin_offset(self, offset):#The point of origin offset of the simulationMap entity is set using the 'set_origin_offset' function. For the purpose of converting GPS coordinates to array indices on a map, the origin offset is a point that aids in establishing the reference point or coordinate system.
        # The method takes a single argument offset, containing GPS coordinates for the origin point, and sets the origin_offset attribute of the simulationMap object to the offset value. This establishes a reference point for mapping GPS coordinates (0,0) into array indices, simplifying vehicle position and movement visualization.
        self.origin_offset = offset  #

    def set_charging_point(self): # On the simulation map, a charging point is defined using the 'set_charging_point' method. An area where the car can recharge its batteries is referred to as a charging point.
        self.charging_points.append(self.current_position) # The list of charging_points has been broadened to include the vehicle's current location (self.current_position). This indicates that the location of the car as it is right now on the map is designated as a charging point.
        print(f'Charging coordinates: {self.charging_points}')
        self.map[self.current_position[0], self.current_position[1]] = (160,159,199) # Change map color to display charging point location visually by accessing self.map array and current_position coordinates.

    # Encoding the gps values to the map array indices
    def encode_gps(self, gps_value):# The encode_gps method converts GPS coordinates into array indices for accessing position in simulation map array, using input pairs.
        #Subtracting origin offset x-coordinate from GPS value to obtain relative coordinates (g1,g2).
        g1 = gps_value[0] - self.origin_offset[0]  # x-axis
        g2 = gps_value[1] - self.origin_offset[1]  # y-axis
        # Scaleing g1 and g2 coordinates by map_scale_factor, reducing resolution and making the map more manageable.
        g1 = g1 // self.map_scale_factor
        g2 = g2 // self.map_scale_factor
        # Method calculates GPS indices (x, y) for simulation map position.
        x = int((self.map.shape[0] // 2) + g1)
        y = int((self.map.shape[1] // 2) + g2)
        return x, y

    def decode_gps(self, x, y):# The array indices from the simulation map are changed back into GPS coordinates using the decode_gps function. It returns the corresponding GPS coordinates after receiving the array indexes (x, y) as input.
        # Calculates relative x and y coordinates of array index x and y by subtracting half of map size, reversing encode_gps method's x-coordinate calculation.
        g1 = x - (self.map.shape[0] // 2)
        g2 = y - (self.map.shape[1] // 2)
        # Scales x and y coordinates by map_scale_factor, reverses encode_gps method scaling-down procedure.
        g1 = g1 * self.map_scale_factor
        g2 = g2 * self.map_scale_factor
        # Final GPS coordinates are obtained by adding origin offset x-coordinate to g1 and y-coordinate to g2, reversing offset in encode_gps procedure.
        g1 = g1 + self.origin_offset[0]
        g2 = g2 + self.origin_offset[1]

        return g1, g2

    # Setting previous position
    def update_previous_position(self):# Update_previous_position method updates simulation map's previous position, storing vehicle's recent visits.self.previous_position_set.add(self.current_position)
        
        if len(self.previous_position_set) < 2: # checks if the size of the previous_position_set is less than 2. If there are fewer than two unique positions in the set, it means that the vehicle has not yet visited two different locations.
            return

        self.previous_position = self.previous_position_set.pop()# The pop() method removes one position from the previous_position_set, indicating the car has visited two separate locations.


    # Update map as per the gps values
    def update(self, gps_value, vehicle_state, is_charging): # The update method updates the simulation map based on GPS value, car condition, and charging level, monitoring vehicle location.
        # Apply offset
        x, y = self.encode_gps(gps_value) # With the help of the gps_value, the encode_gps method is invoked, which uses the GPS coordinates to determine the relevant array indices (x and y) in the simulation map.

        # Update the value at the index as road
        self.current_position = (x, y) # represents the current location of the vehicle in the simulation map

        self.update_previous_position()# to keep track of the recent positions visited by the vehicle

        if is_charging:
            self.map[x, y] = ((0, 0, 255)) # If the vehicle is in a charging state, it sets the value of the simulation map at the current position (x, y) to ((0, 0, 255)) (which means red color).
          
        else:
            self.map[x, y] = (160,159,199)# If the vehicle is not in a charging state (i.e., it is on the road), it sets the value of the simulation map at the current position (x, y) to (160,159,199)


    def get_map(self): # Get_map method accesses state of simulation map as NumPy array.
        with open('map_data.pkl', 'wb') as file:
            pickle.dump(self.map, file)
        return self.map

    def show(self):
        cv2.namedWindow('SimulationMap', cv2.WINDOW_NORMAL)
        cv2.resizeWindow('SimulationMap', 256 * 2, 256 * 2)

        tmp = self.map.copy()

        if len(self.path) > 0:
            path_map = tmp.copy()
            path = self.path.copy()

            # ##Draw the path on the image
            for i in range(len(path) - 1):
                path_map[path[i][1], path[i][0]] = (222,100,212)

            tmp = cv2.addWeighted(tmp, 1, path_map, 0.8, 0)

        if len(self.charging_points) > 0:
            for charging_point in self.charging_points:
                tmp[charging_point[0], charging_point[1]] = (222,100,212)

        tmp[self.current_position[0], self.current_position[1]] = (0,160,210)
        cv2.imshow('SimulationMap', tmp)

    # Find the path to the charging points
    def path_to_charging_points(self):

        if len(self.charging_points) == 0:
            print('No Charging area Detected!!!')
            return

        paths = []

        for charging_point in self.charging_points:
            _, threshold_image = cv2.threshold(cv2.cvtColor(self.map, cv2.COLOR_BGR2GRAY), 250, 255,
                                               cv2.THRESH_BINARY_INV)

            # Convert the threshold image to a binary grid
            binary_grid = (threshold_image > 0).astype(np.uint8)

            start_position = (self.current_position[1], self.current_position[0])
            end_position = (charging_point[1], charging_point[0])

            grid = Grid(matrix=binary_grid)

            # Get the start and end nodes
            start_node = grid.node(*start_position)
            end_node = grid.node(*end_position)

            # Using Dijkstra Finder and find the path from current position to the charging point
            finder = DijkstraFinder(diagonal_movement=DiagonalMovement.always)
            path, _ = finder.find_path(start_node, end_node, grid)

            # print('Detected Path : ', path)
            paths.append(path)

        if len(paths) > 0:
            self.path = min(paths, key=len)
            print('Short path: ', len(self.path))
