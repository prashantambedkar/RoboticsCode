#Task 3: The goal of the robot is to explore the area by taking left and right turns for each intersection until its battery level runs low. When the battery level becomes critical, the robot must prioritize reaching the charging area to avoid running out of power. Once at the charging area, the robot will stop taking random turns and focus on charging until it reaches a sufficient level. After charging, the robot must resume its initial goal of exploring the area by taking random turns again.
# An element of autonomous robotic systems that allows them to move and navigate in the environment is the navigation robotic subsystem (RAS unit-3). A path to a destination is planned and carried out using algorithms and a variety of sensors, including cameras (RAS unit-8) and GPS. This experiment makes use of an autonomous vehicle with an ackerman drive (RAS unit 7). The vehicle is equipped with a GPS sensor and RGB camera.
# The concept is based on motion and planning from RAS Unit 11 (Path and Motion Planning).

# We are relied on random turns to explore the entire region and find the charging area, but this approach was based on luck and chance. Sometimes, the car's battery would drain out completely before the charging area was discovered. 


import numpy as np

from rasrobot import RASRobot

from CarMovements import *
from SimulationMap import simulationMap

import cv2

from collections import deque


class MyRobot(RASRobot):
    def __init__(self):
        """
        The constructor has no parameters.
        """
        super(MyRobot, self).__init__()


        self.queue = deque(maxlen=15)

        self.vehicle_state = None #self.currentVehicleState

        self.start_point = None #self.startingpt

        # simulationMap for mapping path and Navigation
        self.simulationMap = simulationMap(size=50, map_scale_factor=40)

        self.previous_charge = 440

    def is_charging(self): # The is_charging function evaluates battery or energy storage system activity by comparing current charge level to a predefined threshold, indicating charging or charging.
        # previous_charge represents battery charge level, self.time_to_live represents threshold value for efficient system operation.
        return self.previous_charge <= self.time_to_live

    def is_low_charge(self):# The is_low_charge function checks if a battery's remaining charge level is low by comparing it to a 130-point threshold value.
        
        return self.time_to_live <= 130

    def is_charged(self):
        return self.time_to_live >= 1 * 240

    def get_road(self):# Function get_road in autonomous driving or robotics processes camera image for road information extraction.
        """
        This method relies on the `get_camera_image` method from RASRobot. It takes the image, converts
        it into HSV (Hue, Saturation, Value) and filters pixels that belong to the three following
        ranges:
        - Hue: 0-200 (you may want to tweak this)
        - Saturation: 0-50    (you may want to tweak this)
        - Value: 0-100    (you may want to tweak this)
        """
        image = self.get_camera_image()

        # Pre-process the image
        processed_mask = pre_process_image(image)# Pre_process_image function extracts road and relevant information from image, storing it in processed_mask.

        # Lane Region of Interest Mask
        roi_mask = getRegionMaskValue(image, roi_type='lane')

        processed_mask = cv2.bitwise_and(processed_mask, roi_mask)# Processed_mask and lane ROI mask refined using bitwise AND operation.

        # Apply the mask to the image
        image_view = apply_mask(image, roi_mask)# Apply_mask function highlights lane region in image by filling contour with roi_mask.

        return image, cv2.morphologyEx(image_view, cv2.MORPH_OPEN, (3, 3)), processed_mask

    def run(self):
        """
        This function implements the main loop of the robot.
        """
        prev_turn_rate = 0
        prev_charging_state = False

        while self.tick():

            # Setting initial offset to the origin
            if self.start_point is None:# Initialize vehicle's GPS position and set origin offset for simulation map.
                self.start_point = self.get_gps_values()
                self.simulationMap.set_origin_offset(self.start_point)

            speed = 50

            raw_image, image, road_mask = self.get_road()# the get_road method to get the raw camera image, processed image with road mask, and information about the presence of a stop sign.
                        
            turn_rate, v_state = TurningValueofPath(image, road_mask, prev_turn_rate, self.vehicle_state, self.is_low_charge(), self.simulationMap)# Calculates turn rate and vehicle state using image and road mask, considering low charge state and zebra crossing presence.
            
            self.vehicle_state = v_state

            if self.is_low_charge() and not self.is_charging() and int(self.time_to_live) % 20 == 0:
                print(f'Charge Draining: {self.time_to_live}')

            # Clear path once reached to charging points
            if self.is_charging():# The is_charging function evaluates battery or energy storage system activity by comparing current charge level to a predefined threshold, indicating charging or charging.
            # previous_charge represents battery charge level, self.time_to_live represents threshold value for efficient system operation.
                self.simulationMap.path.clear()
                
            # The vehicle's speed is determined by turn rate, with a default speed of 15 for large turns and 40 for zebra crossings without stop signs.
            if abs(turn_rate) >= 20:
                speed = carturnspeed

            # Wait until 100% charged
            if self.is_charging() and not self.is_charged():
                speed = 20
                
            self.set_speed(speed)
            self.set_steering_angle(turn_rate / 100)

            prev_turn_rate = turn_rate

            # Update the simulationMap based on gps
            self.simulationMap.update(self.get_gps_values(), self.vehicle_state, self.is_charging())

            # Set charging point once identified (start point)
            if self.is_charging() and len(self.simulationMap.charging_points) == 0:
                    self.simulationMap.set_charging_point()

            # Set charging point once identified (end point)
            if not self.is_charging():
                if prev_charging_state and len(self.simulationMap.charging_points) == 1:
                    self.simulationMap.set_charging_point()



            self.previous_charge = self.time_to_live
            prev_charging_state = self.is_charging()
   
            print(f'Time to live: {self.time_to_live}')

            print(f'GPS: {self.get_gps_values()}')

            cv2.imshow('output', self.get_camera_image())

            cv2.imshow('Simulation Map',self.simulationMap.get_map())

            print('We relied on random turns to explore the entire region and find the charging area, but this approach was based on luck and chance. Sometimes, the cars battery would drain out completely before the charging area was discovered. ')

            print('If Battery Drains out completely without exploring charging and other areas, then Please Re-Run the code!!')

            print('-----------------------------------------------------------------------------------------------------------------')

            # cv2.imshow("Simulation Map", self.simulationMap.get_map())
            self.simulationMap.show()
            cv2.waitKey(1)


# The API of the MyRobot class, is extremely simple, not much to explain.
# We just create an instance and let it do its job.
robot = MyRobot()
robot.run()
