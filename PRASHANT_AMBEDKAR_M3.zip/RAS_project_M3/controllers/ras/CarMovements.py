import math
import random
import numpy as np
import cv2
from InitVariables import *
from SimulationMap import simulationMap

# Display Image
def display_image(image, name, size=(256 * 2, 128 * 2)):
    cv2.namedWindow(name, cv2.WINDOW_NORMAL)
    cv2.resizeWindow(name, size[0], size[1])
    cv2.imshow(name, image)


# To get Region of Interest Mask
def getRegionMaskValue(image, roi_type='lane'):# The getRegionMaskValue function generates a binary mask representing ROI in input images, aiming to draw attention to specific areas for computer vision applications like lane detection and sign detection.
       
    if type == 'lane':# A `roi_type` indicating region of interest, 'lane' or'signRoi', generates mask based on lane region or signRoi
        viewport = laneroi
    elif roi_type == 'sign':
        viewport = signroi
    else:
        viewport = laneroi

    view_mask = np.zeros((image.shape[0], image.shape[1]), dtype=np.uint8)
    cv2.fillPoly(view_mask, viewport, (255, 255, 255))

    return view_mask


# To Apply Mask to image
def apply_mask(image, roi_mask, color=(0, 255, 0), thickness = cv2.FILLED):# The program uses apply_mask to apply a filled mask to ROI, visually highlighting it with a specific color.
        
    roi_contours, _ = cv2.findContours(roi_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    filled_contours = np.zeros_like(image)
    cv2.drawContours(filled_contours, roi_contours, -1, color, thickness)

    image = cv2.addWeighted(image, 1, filled_contours, 0.25, 0)# The cv2.addWeighted function overlays filled contours on input image, using a weighted sum to enhance prominence while preserving original content.
        
    return image


# Getting the color mask based on HSV thresholds
def ColorMaskValue(hsv, low, high):# creating a binary mask based on threshold values, ColorMasKValue isolates particular colours in an HSV image.
    
    mask = cv2.inRange(hsv, low, high) # The function creates a binary mask, setting white pixels within the HSV range and black pixels outside, isolating desired color in image.        
        
    # Apply the erode operation
    mask = cv2.erode(mask, (1, 1), iterations=1)# Erode reduces white regions in binary masks by moving kernel and setting pixel to white.

    # Apply the dilation operation
    mask = cv2.dilate(mask, (3, 3), iterations=2)# Dilation increases white regions in binary masks by filling gaps and joining isolated color regions in 3x3 kernel operations.
    

    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, (5, 5), iterations=5)# Closing is a morphological operation involving dilation and erosion, closing gaps in binary masks using a 5x5 kernel five times.
    
    # Apply a Gaussian blur to reduce noise
    mask = cv2.GaussianBlur(mask, (5, 5), 0)# Gaussian blur reduces noise in binary mask using (5, 5) kernel size and 0 standard deviation of Gaussian function.
        
    return mask


# Preprocessing the image
def pre_process_image(image):# The pre_process_image function preprocesses input image to create binary masks for lane and crossing detection.
        
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)# HSV color space separates hue information from brightness and saturation, enabling better color range management.
   
    crossing_mask = ColorMaskValue(hsv, crossValueL, crossValueH)# Crossing_mask is a mask created using ColorMasKValue function, detecting specific colors related to crossings or intersections.
        
    lane_mask = ColorMaskValue(hsv, yellowLane_L, yellowLane_H)# Lane_mask is a mask created using ColorMasKValue function, detecting yellow lane markings based on HSV thresholds.
        
    tmp_mask = cv2.bitwise_and(lane_mask, crossing_mask)# Temporary mask tmp_mask is computed by bitwise AND operation, isolating common areas satisfying color criteria.
        
    mask = cv2.bitwise_or(lane_mask, tmp_mask)# Mask is created by bitwise OR operation, combining lanes and crossing detections.
    
    return mask


# To detect the bumpy crossings
def cross_ahead(image):# The cross_ahead function is used to determine whether an input image has a crossing or an intersection.
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    crossing_mask = ColorMaskValue(hsv, crossValueL, crossValueH)
    x = find_counters(crossing_mask, min_area=150)
    if len(x) > 0:
        largest_contour = np.vstack(x)
        if cv2.contourArea(largest_contour) > 500:
            return True

    return False


# Finding the contours for the mask
def find_counters(mask, min_area=0):# The find_counters method is used to find contours in a binary image (also known as a mask) and optionally filter those contours based on their area. Contours are the boundaries of objects or regions of interest in an image.

    # Find the contours in the binary image
    contours, _ = cv2.findContours(mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    # Filter the contours based on the area
    if min_area > 0:
        filtered_contours = []
        for contour in contours:
            if cv2.contourArea(contour) > min_area:# Check contour area using OpenCV's cv2.contourArea() function, indicating a valid object or region of interest if it exceeds min_area.
                   
                filtered_contours.append(contour)
        return filtered_contours
    return contours


# Picking Random Turn
def GenerateRandomTurn():
    choice = random.choice(['LEFT', 'RIGHT','STRAIGHT'])
    if choice == 'LEFT':
        steering_angle = -steeringanglevalue
    elif choice == 'RIGHT':
        steering_angle = steeringanglevalue
    else:
        steering_angle=0
    return steering_angle


# To find angle between two points
def angle_between_points(point1, point2):
    delta_x, delta_y = point2[0] - point1[0], point2[1] - point1[1]
    return math.atan2(delta_y, delta_x)


# To find the turn based on previous location, current and next nav location
def find_turn_angle(prev, curr, next):
    angle1 = angle_between_points(prev, curr)
    angle2 = angle_between_points(curr, next)
    turn_angle = (angle2 - angle1 + 2 * math.pi) % (2 * math.pi)

    # print(prev, curr, next)
    # print(f'Turn angle: {math.degrees(turn_angle)}')

    if turn_angle == 0:
        return 'STRAIGHT'
    elif turn_angle == math.pi / 2 or 0 < turn_angle < math.pi:
        return 'RIGHT'
    elif turn_angle == 3 * math.pi / 2 or math.pi < turn_angle < 2 * math.pi:
        return 'LEFT'


# To find the turn rate for the vehicle
def TurningValueofPath(image, road_mask, prev_steering_angle, vehicle_state, is_low_charge, simulationMap):# The TurningValueofPath function is used to determine the appropriate steering angle for the autonomous vehicle based on the current state of the vehicle and the information extracted from the input image and road mask.
        
    steering_angle = 0

    # Find the contours in the binary image
    contours = find_counters(road_mask, min_area=100)

    # If any contours are found, select the one with the largest area
    if len(contours) > 0:# The function searches for the greatest contour (largest connected region representing the lane) if any contours are detected (len(contours) > 0), which indicates that the vehicle is on a lane.
            
        vehicle_state = 'lane'
        largest_contour = max(contours, key=cv2.contourArea)

        # Find the centroid of the largest contour
        M = cv2.moments(largest_contour)

        if M['m00'] == 0 or M['m01'] == 0:
            return steering_angle

        cx = int(M['m10'] / M['m00'])# Calculate the centroid (cx) of the largest contour. The centroid represents the center point of the lane.
    

        steering_angle = cx - len(image[0]) // 2# Calculate the steering angle as the difference between the centroid position and the center of the image (half of the image width). This helps to steer the vehicle towards the center of the lane.
            
   
    elif vehicle_state != 'intersection' and not cross_ahead(image):
        vehicle_state = 'intersection'

        

        # If low charge, find the path to the charging points
        if is_low_charge:
            simulationMap.path_to_charging_points()

            # If path is found, find the turn angle
            if len(simulationMap.path) > 0: # The function uses the find_turn_angle function to determine the turn angle based on the previous position (pp), current position (cp), and next location (n1) on the path if a path to charging sites is detected (len(self.simulationMap.path) > 0).
                    
                pp = (simulationMap.previous_position[1], simulationMap.previous_position[0])
                cp = (simulationMap.current_position[1], simulationMap.current_position[0])
                n1 = simulationMap.path[0]

                turn = find_turn_angle(pp, cp, n1)
                print('Select n1: ', turn)

                if turn == 'LEFT':
                    steering_angle = -steeringanglevalue
                elif turn == 'RIGHT':
                    steering_angle = steeringanglevalue
                else:
                    steering_angle = 0
        else:
            # Default (Random) Turn
            steering_angle = GenerateRandomTurn()
        

    else:
        steering_angle = prev_steering_angle


    steering_angle = np.clip(steering_angle, -steeringanglevalue, steeringanglevalue)

    return steering_angle, vehicle_state
