from enum import Enum

import numpy as np


   # Constants for the RAS project


laneroi = np.array([
    [(40, 120), (216, 120), (196, 90), (50, 90)]
])
yellowLane_L = np.array([20, 100, 100])
yellowLane_H = np.array([40, 150, 255])

# Crossing Markings
crossValueL = np.array([26, 135, 100])
crossValueH = np.array([45, 255, 250])

steeringanglevalue = 26
carturnspeed = 15

signroi = np.array([
    [(200, 100), (255, 100), (255, 40), (200, 40)]
])

laneroi = np.array([
    [(40, 120), (216, 120), (196, 90), (50, 90)]
])


