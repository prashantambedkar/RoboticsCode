# Task 1: Navigation (RAS unit-3):the field of robotics that studies how can robots change their location.
# The objective of the robot car is to smoothly and safely navigate forward, consistently taking right turns without deviating from the tarmac surface. 
# The main focus is to maintain a continuous and controlled movement, ensuring the robot stays on the road throughout its path.

from rasrobot import RASRobot
import numpy as np
import time
import cv2

class MyRobot(RASRobot):
    def __init__(self):
        
        # Set the value for the speed of the car to '50'
        self.Speed=50 
        
        # Set the value for steering angle of car to '0'
        self.steering_angle = 0
        
        #turning Value for steering of car
        self.steeringangleValue = 26
        
        #turn to make 'Right'
        self.turn='RIGHT'
        
        # Crossing Markings
        self.crossValueL = np.array([26, 135, 100])
        self.crossValueH = np.array([45, 255, 250])
        
        # Yellow Lane Markings
        self.yellowLane_L = np.array([20, 100, 100])
        self.yellowLane_H = np.array([40, 140, 250])
        
        super(MyRobot, self).__init__()

        # Initialise and resize a new window 
        cv2.namedWindow("output", cv2.WINDOW_NORMAL)
        cv2.resizeWindow("output", 128*4, 64*4)
        
        cv2.namedWindow("Lane Detection", cv2.WINDOW_NORMAL)
        cv2.resizeWindow("Lane Detection", 128*4, 64*4)

    def crossRegion(self,image):
        """
        Function to create a mask for a region of interest in the given image.
    
        Parameters:
        image (numpy.ndarray): The input image on which the region of interest mask will be applied.
    
        Returns:
        numpy.ndarray: A binary mask representing the region of interest in the input image.
        """
        # Defining the veiwport for the region of interest
        viewport = np.array([[(20, 60), (108, 60), (98, 50), (30, 50)]])
    
        # Creating a blank mask
        maskValue = np.zeros((image.shape[0], image.shape[1]), dtype=np.uint8)
    
        # Filling the viewport with white color
        cv2.fillPoly(maskValue, viewport, (255, 255, 255))
    
        return maskValue
        
    def get_road(self):
      
        image = self.get_camera_image()
        # Pre-process the image to get the mask for the lane        
        hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)        
        mask = cv2.inRange(hsv, self.crossValueL, self.crossValueH)
               
        # Apply the erode operation
        mask = cv2.erode(mask, (1, 1), iterations=1)
    
        # Apply the dilation operation
        mask = cv2.dilate(mask, (2, 2), iterations=5)
    
        # Apply a Gaussian blur to reduce noise
        crossing_mask = cv2.GaussianBlur(mask, (5, 5), 0)
        
        mask = cv2.inRange(hsv, self.yellowLane_L, self.yellowLane_H)
         # Apply the erode operation
        mask = cv2.erode(mask, (1, 1), iterations=1)
    
        # Apply the dilation operation
        mask = cv2.dilate(mask, (2, 2), iterations=4)
    
        # Apply a Gaussian blur to reduce noise
        lane_mask = cv2.GaussianBlur(mask, (5, 5), 0)
        
        # Combining masks to get the final mask
        tmp_mask = cv2.bitwise_and(lane_mask, crossing_mask)
        processed_mask = cv2.bitwise_or(lane_mask, tmp_mask)        
        
        # Get the region of interest mask
        roi_mask = self.crossRegion(image)

        # Apply the mask to the processed image
        processed_mask = cv2.bitwise_and(processed_mask, roi_mask)

        # Find the contours in the binary image
        contours, _ = cv2.findContours(processed_mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
        minarea = 51
        filtered_contours = []
        for contour in contours:
            if cv2.contourArea(contour) > minarea:
                filtered_contours.append(contour)

        # Apply the mask to the original image
        roi_contours, _ = cv2.findContours(roi_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
               
        image = cv2.addWeighted(image, 1, np.zeros_like(image), 0.25, 0)

        return image, filtered_contours
       
    # for making smooth turns on road    
    def makeTurninRoad(self,image, contours):
        
       # If any contours are found, select the one with the largest area
        if len(contours) > 0:
            largest_contour = max(contours, key=cv2.contourArea)
    
            # Find the centroid of the largest contour
            M = cv2.moments(largest_contour)
    
            if M['m00'] == 0 or M['m01'] == 0:
                return steering_angle
    
            crosX = int(M['m10'] / M['m00'])
            
            # Identify Center of road to center of capturing frame
            self.steering_angle = crosX - len(image[0]) // 2
            
        else:
            self.steering_angle = self.steeringangleValue   
            #self.steering_angle = -self.steeringangleValue  # '-' for checking left turn
        return self.steering_angle
    
    def checkEdges(self):
        # Get the camera image and convert it to grayscale
        image = self.get_camera_image()
        image = cv2.resize(image, (600,600))
        image = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)  # convert to LAB color space
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))  # create a CLAHE object
        image[:,:,0] = clahe.apply(image[:,:,0])  # apply CLAHE to the L channel
        image = cv2.cvtColor(image, cv2.COLOR_LAB2BGR)  # convert back to BGR color space
        # Convert to HSV color space
        hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
        #crosswalk=self.detect_crossing(image)
        
        # Create mask to extract yellow pixels
        #20, 60, 100
        yellowLL = np.array([20, 60, 100])
        #yellowUL = np.array([35, 167, 166])
        #yellowUL = np.array([36, 160, 162])
        yellowUL = np.array([30, 130, 200])
        mask_yellow = cv2.inRange(hsv, yellowLL, yellowUL)
    
        # Apply Gaussian blur to mask
        mask_blur = cv2.GaussianBlur(mask_yellow, (5, 5), 0)
    
        # Apply Canny edge detection to mask
        edges = cv2.Canny(mask_blur, 100, 200)
        
        return edges
        
    def run(self):
        while self.tick():
            road, contours = self.get_road()
            edges=self.checkEdges()
            # Display the output image with the detected edges
            output = np.dstack((edges, edges, edges))
            # Check and identify lane and make turn angle for the car
            RateTurn = self.makeTurninRoad(road, contours)
            #print(RateTurn)
            # Adjusting speed of the car while moving in turn
            if abs(RateTurn) > 24:
                Speedofcar=15
            else:
                Speedofcar=self.Speed 
                   
            self.set_speed(Speedofcar)
            self.set_steering_angle((RateTurn / 100))
            print('Speedofcar : ',Speedofcar)
            # Display the image
            cv2.imshow('output', road)
            cv2.imshow('Lane Detection', output)
            cv2.waitKey(1)

# The API of the MyRobot class, is extremely simple, not much to explain.
# We just create an instance and let it do its job.
robot = MyRobot()
robot.run()


