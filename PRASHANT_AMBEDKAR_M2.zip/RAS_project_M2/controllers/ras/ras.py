# Task 2: The enhanced goal of the robot is to extend its capabilities from the previous mission and now detect stop signs. Whenever a stop sign is detected in front of the car, the robot must come to a complete stop. 
# Once it halts, it should remain stationary for one second and then resume moving forward.

# The car's behavior can be described as a hybrid of deliberative and reactive components. It possesses both deliberative capabilities for planned actions and a reactive nature for real-time responses. 
# It follows a set of predefined instructions to move within its lane, which reflects its deliberative aspect. Simultaneously, it remains reactive to its environment through the incorporation of sensors, allowing it to detect and respond to stop signs. When a stop sign is detected, the car halts its motion in real-time, demonstrating its reactive nature. After pausing for one second, it resumes its movement, thereby combining planned actions with on-the-spot adaptability.

import time
from rasrobot import RASRobot
import numpy as np
import random
import cv2

class MyRobot(RASRobot):

    vehicle_state = None
    last_stop_time = None
    stop_templates = []
    
    def get_stop_templates(self): # Using the get_stop_templates method, which recognises and reacts to stop signs by using the match_templates and scan_for_template methods, the robot initialises stop sign visuals.
        stopimagearray = [] # The stop sign images in preprocessed grayscale will be kept in this empty list.
        for i in range(0, 5): # Five stop sign images are loaded during each of the loop's five iterations. It is assumed that the directory specified contains five stop sign images with the names "StopImages_0.png," "StopImages_1.png,"..., "StopImages_4.png."
            stopimageP = cv2.imread(f'../../controllers/ras/StopImages/StopImages_{i}.png') #The image is read using the OpenCV cv2.imread() function in BGR (Blue, Green, Red) format.
            stopimageP = cv2.resize(stopimageP, (24, 24), interpolation=cv2.INTER_LINEAR) #The image has been diminished to a 24x24 pixel size. Downsizing the images will speed up the template matching process.
            stopgraycv = cv2.cvtColor(stopimageP, cv2.COLOR_BGR2GRAY) #converts the resized BGR image to grayscale. 
            stopimagearray.append(stopgraycv) #The stopimagearray list is expanded to include the preprocessed grayscale image.
        return stopimagearray
        
    def __init__(self):
    
        # Set the value for speed of car to '50'
        self.Speed=35
        
        # Set the value for steering angle of car to '0'
        self.steering_angle = 0
        
        #turning Value for steering of car
        self.steeringangleValue = 26
        self.stopsignIdentified=0
        self.prev_turn_rate=0
        #turn to make 'Right'
        self.turn='RIGHT'
        
        # Crossing Markings
        self.crossValueL = np.array([26, 135, 100])
        self.crossValueH = np.array([45, 255, 250])
        
        # Yellow Lane Markings
        self.yellowLane_L = np.array([20, 100, 100])
        self.yellowLane_H = np.array([40, 140, 250])

        self.signRoi = np.array([[(200, 100), (255, 100), (255, 40), (200, 40)]])
        
        self.laneroi = np.array([[(40, 120), (216, 120), (196, 100), (50, 100)]])
        super(MyRobot, self).__init__()

        # Initialise and resize a new window 
        cv2.namedWindow("output", cv2.WINDOW_NORMAL)
        cv2.resizeWindow("output", 256*2, 128*2)
        
        cv2.namedWindow("Lane Detection", cv2.WINDOW_NORMAL)
        cv2.resizeWindow("Lane Detection", 128*4, 64*4)


        self.stop_templates = self.get_stop_templates()
        self.stop_timer = None
        

    def rotationfrompath(self,image, contours, prev_steering_angle, vehicle_state):# The TurningValueofPath function is used to determine the appropriate steering angle for the autonomous vehicle based on the current state of the vehicle.
        steering_angle = 0      
    
        # If any contours are found, select the one with the largest area
        if len(contours) > 0:
            vehicle_state = 'lane'
            largest_contour = max(contours, key=cv2.contourArea)
    
            # Find the centroid of the largest contour
            M = cv2.moments(largest_contour)
    
            if M['m00'] == 0 or M['m01'] == 0:
                return steering_angle
    
            cx = int(M['m10'] / M['m00']) # Calculate the centroid (cx) of the largest contour. The centroid represents the center point of the lane.
            
    
            steering_angle = cx - len(image[0]) // 2# Calculate the steering angle as the difference between the centroid position and the center of the image (half of the image width). This helps to steer the vehicle towards the center of the lane.
    

    
        elif vehicle_state != 'intersection':
            # No Lanes at Intersection, Take right turn as part of Mission-1
            
            #choice = random.choice(['LEFT', 'RIGHT'])
            choice = 'RIGHT'
            # choice = 'LEFT'
            if choice == 'LEFT':
                steering_angle = -self.steeringangleValue
            else:
                steering_angle = self.steeringangleValue
    
            vehicle_state = 'intersection'
    
        else:
            steering_angle = self.steeringangleValue
    
        return steering_angle, vehicle_state

                   
    def get_sign_mask(self,img): # The get_sign_mask method in the MyRobot class isolates potential stop signs in camera images before matching templates to find them.
        """
         # Step 1: Convert the input image to HSV color space for color segmentation
         # Define HSV thresholds for the red color using two ranges to handle hue channel wraparound
         # Step 2: Create a binary mask for the red color using inRange function and apply Gaussian blur
         # Step 3: Apply morphological operations to the mask to eliminate noise and smooth the detected red regions
         # Step 4: Return the resulting mask with potential stop sign regions isolated
    
        """
        
        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV) # For colour segmentation, which separates colour information from intensity, the input image is converted to HSV colour space.
        # Using two ranges (red_1L to red_1U,red_2L to red_2U) in OpenCV for hue channel wraparound, define HSV thresholds for the red colour.
        red_1L = np.array([0, 50, 49])
        red_1U = np.array([10, 255, 254])
        red_2L = np.array([160, 31, 29])
        red_2U = np.array([181, 255, 254])
    
        # Create a mask for the red color
        kernel_size = (1, 1)
        mask1 = cv2.GaussianBlur(cv2.inRange(hsv, red_1L, red_1U), kernel_size, 0)
        mask2 = cv2.GaussianBlur(cv2.inRange(hsv, red_2L, red_2U), kernel_size, 0)
        mask = cv2.bitwise_or(mask1, mask2)# Binary mask for red colour regions with 255 red and 0 other pixels is produced by bitwise ORing mask combinations.
    
        # Apply morphological operations to the mask
        kernel = np.ones((3, 3), np.uint8) # To continue processing the mask, a 3x3 kernel is produced for morphological operations.
    
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel) # To eliminate noise and smooth down any red zones that were detected, the mask is opened.
        
        return mask    
    
    def match_templates(self,stop_roi, stop_templates, threshold=0.5):
        for i in range(0, 4):
            res = cv2.matchTemplate(stop_roi, stop_templates[i], cv2.TM_CCOEFF_NORMED)
            loc = cv2.minMaxLoc(res)
    
            # If the match value is above the threshold, a stop sign is detected
            if loc[1] > threshold:
                return True, loc[1]
        return False, 0   
         
    def scan_for_template(self,img, stop_templates):
        """
        Scans an input image for a stop sign template and performs template matching to detect stop signs.
    
        Args:
            img (numpy array): The input image to be scanned for stop signs.
            stop_templates (list): A list of stop sign templates used for template matching.
    
        Returns:
            img (numpy array): The input image with optional visual enhancements if a stop sign is detected.
            stop_sign_detected (bool): A flag indicating whether a stop sign was detected in the image.
        """
        
        stop_sign_detected = False
    
        # Get the mask for the stop sign
        sign_mask = self.get_sign_mask(img)
    
        # Find contours in the mask
        contours, hierarchy = cv2.findContours(sign_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
        # Iterate through each contour and perform template matching
        for contour in contours:
    
            # Check if the contour is within the region of interest
            is_in_roi = cv2.pointPolygonTest(self.signRoi, tuple(contour.tolist()[0][0]), False)
            if is_in_roi < 0:
                continue
    
            # Get the bounding box of the contour
            x, y, w, h = cv2.boundingRect(contour)
    
            # Crop the image to the bounding box
            roi = img[y:y + h, x:x + w]
    
            # Resize the image to the size of the template
            roi = cv2.resize(roi, (24, 24), interpolation=cv2.INTER_AREA)
    
            # Convert the cropped image to grayscale
            gray_roi = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
    
            # Perform template matching
            is_match, match_value = self.match_templates(gray_roi, stop_templates, 0.5)
                
            if is_match:
                img_tmp = img.copy()
                img = cv2.addWeighted(img, 1, img_tmp, 0.25, 0)
                self.stopsignIdentified=1
                stop_sign_detected = True
                break
    
        #cv2.polylines(img, SIGNS_ROI, True, (0, 255, 0), 2)#255, 0, 0
        return img, stop_sign_detected
        
    def clean(self,mask):
        # Apply the erode operation
        mask = cv2.erode(mask, (1, 1), iterations=1)
    
        # Apply the dilation operation
        mask = cv2.dilate(mask, (2, 2), iterations=5)
    
        # Apply a Gaussian blur to reduce noise
        mask = cv2.GaussianBlur(mask, (5, 5), 0)
    
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, (3, 3))
    
        return mask  
          
    def ColorMasKValue(self,hsv, low, high):# creating a binary mask based on threshold values, ColorMasKValue isolates particular colours in an HSV image.
        mask = cv2.inRange(hsv, low, high) # The function creates a binary mask, setting white pixels within the HSV range and black pixels outside, isolating desired color in image.        
        mask = self.clean(mask)
        return mask      
        
    def get_roi(self,image, roi_type='lane'):# The get_roi function generates a binary mask representing ROI in input images, aiming to draw attention to specific areas for computer vision applications like lane detection and sign detection.
        if type == 'lane': # A `type` indicating region of interest, 'lane' or'signRoi', generates mask based on lane region or signRoi. 
            viewport = self.laneroi
        elif roi_type == 'sign':
            viewport = self.signRoi
        else:
            viewport = np.array([[(40, 120), (216, 120), (196, 100), (50, 100)]])
    
        view_mask = np.zeros((image.shape[0], image.shape[1]), dtype=np.uint8)
        cv2.fillPoly(view_mask, viewport, (255, 255, 255))
    
        return view_mask
    
    # Preprocessing the image
    def pre_process_image(self,image): # The pre_process_image function preprocesses input image to create binary masks for lane and crossing detection.
        hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV) # HSV color space separates hue information from brightness and saturation, enabling better color range management.
    
        crossing_mask = self.ColorMasKValue(hsv, self.crossValueL, self.crossValueH) # Crossing_mask is a mask created using ColorMasKValue function, detecting specific colors related to crossings or intersections.
        lane_mask = self.ColorMasKValue(hsv, self.yellowLane_L, self.yellowLane_H) # Lane_mask is a mask created using ColorMasKValue function, detecting yellow lane markings based on HSV thresholds.
        tmp_mask = cv2.bitwise_and(lane_mask, crossing_mask) # Temporary mask tmp_mask is computed by bitwise AND operation, isolating common areas satisfying color criteria.
        mask = cv2.bitwise_or(lane_mask, tmp_mask) # Mask is created by bitwise OR operation, combining lanes and crossing detections.
    
        return mask  
        
        
    def apply_mask(self,image, roi_mask, color=(0, 255, 0), thickness = cv2.FILLED):
        roi_contours, _ = cv2.findContours(roi_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
        filled_contours = np.zeros_like(image)
        
        image = cv2.addWeighted(image, 1, filled_contours, 0.26, 0)
        return image 
        
    def get_road(self):
        """
        This method relies on the `get_camera_image` method from RASRobot. It takes the image, converts
        it into HSV (Hue, Saturation, Value) and filters pixels that belong to the three following
        ranges:
        - Hue: 0-200 (you may want to tweak this)
        - Saturation: 0-50    (you may want to tweak this)
        - Value: 0-100    (you may want to tweak this)
        """
        image = self.get_camera_image()

        # Pre-process the image
        processed_mask = self.pre_process_image(image)# Pre_process_image function extracts road and relevant information from image, storing it in processed_mask.

        # Get the region of interest mask for the lane
        roi_mask = self.get_roi(image, 'lane')# Get lane ROI mask using getRegionMaskValue function to focus on expected lane markings.

        # Combine the two masks
        processed_mask = cv2.bitwise_and(processed_mask, roi_mask) # Processed_mask and lane ROI mask refined using bitwise AND operation.

        # Find the contours in the binary image
        contours, _ = cv2.findContours(processed_mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
        min_area = 100
        filtered_contours = []
        for contour in contours:
            # print(cv2.contourArea(contour))
            if cv2.contourArea(contour) > min_area:
                filtered_contours.append(contour)

        # Scan for stop signs
        image_view, stop_sign = self.scan_for_template(image, self.stop_templates)

        # Apply the mask to the image
        image_view = self.apply_mask(image_view, roi_mask)

        return cv2.morphologyEx(image_view, cv2.MORPH_OPEN, (3,3)), filtered_contours, stop_sign
    
    def checkEdges(self):
        # Get the camera image and convert it to grayscale
        image = self.get_camera_image()
        image = cv2.resize(image, (600,600))
        image = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)  # convert to LAB color space
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))  # create a CLAHE object
        image[:,:,0] = clahe.apply(image[:,:,0])  # apply CLAHE to the L channel
        image = cv2.cvtColor(image, cv2.COLOR_LAB2BGR)  # convert back to BGR color space
        # Convert to HSV color space
        hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
        #crosswalk=self.detect_crossing(image)
        # Create mask to extract yellow pixels
        #36, 158, 160
        yellowLL = np.array([20, 60, 100])
        #yellowUL = np.array([35, 167, 166])
        #yellowUL = np.array([36, 160, 162])
        yellowUL = np.array([30, 130, 200])
        mask_yellow = cv2.inRange(hsv, yellowLL, yellowUL)
    
        # Apply Gaussian blur to mask
        mask_blur = cv2.GaussianBlur(mask_yellow, (5, 5), 0)
    
        # Apply Canny edge detection to mask
        edges = cv2.Canny(mask_blur, 100, 200)
        
        return edges
    
    def is_stop_detection_active(self,last_stop_time): # If the stop sign detection should be active or not, it is determined using the is_stop_detection_active method. The method accepts as input the last_stop_time, which denotes the moment the last stop sign was noticed.
        return last_stop_time is None or time.time() - last_stop_time > 10
        
    def run(self):
       
        while self.tick():
            speed = self.Speed
            turn_rate = self.prev_turn_rate
            edges=self.checkEdges()
            # Display the output image with the detected edges
            output = np.dstack((edges, edges, edges))

            road, contours, stop_sign = self.get_road()

            # Check if the stop sign detection is active (not on cooldown)
            if self.is_stop_detection_active(self.last_stop_time):
                if stop_sign is True:
                    self.stop_timer = time.time()
                    self.last_stop_time = time.time()
                    

            if self.stop_timer is not None and time.time() - self.stop_timer < 10:
                speed = 0
            else:
                speed = self.Speed
                self.stop_timer = None

            turn_rate, v_state = self.rotationfrompath(road, contours, self.prev_turn_rate, self.vehicle_state)
            self.vehicle_state = v_state

            turn_rate = np.clip(turn_rate, -self.steeringangleValue, self.steeringangleValue)

            if abs(turn_rate) > 24:
                speed = speed / 2

            self.set_speed(speed)
            self.set_steering_angle(turn_rate / 100)
            if self.stopsignIdentified==1: 
                self.Speed=40
            prev_turn_rate = turn_rate
            prev_speed = speed
            print('Speed of Car: ',speed)
            # Display the image
            cv2.imshow('output', road)
            cv2.imshow('Lane Detection', output)
            cv2.waitKey(1)

# The API of the MyRobot class, is extremely simple, not much to explain.
# We just create an instance and let it do its job.
robot = MyRobot()
robot.run()


